# EduStore secure backend plan (GitHub Pages + Supabase + Razorpay)

GitHub Pages serves static files only. It cannot protect a secret key, authenticate an administrator securely, verify a payment signature, or issue private download permissions. Do not launch paid downloads until the backend steps below are implemented and tested.

## 1. Create a Supabase project

- Create a project in Supabase and keep the project URL and anon/public key for the browser app only.
- Keep the `service_role` key exclusively in Supabase Edge Function secrets. Never commit it to GitHub or put it in browser JavaScript.
- Enable email authentication for administrators. Restrict admin privileges through a server-controlled `profiles`/role table; do not trust a role value supplied by the browser.

## 2. Database schema (starter)

Run in the Supabase SQL editor and review before production:

```sql
create table public.resources (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title_en text not null,
  title_hi text,
  description_en text,
  description_hi text,
  category text not null check (category in (
    'CA Foundation','CA Intermediate','MBBS / Medical',
    'Class 11–12 Commerce','Class 11–12 Science','UPSC / OPSC',
    'NEET / JEE','Other Competitive Exams','Other Subjects'
  )),
  subject text,
  language text not null default 'English',
  access_type text not null check (access_type in ('free','paid')),
  price_paise integer not null default 0 check (price_paise >= 0),
  page_count integer,
  public_file_path text,
  private_file_path text,
  cover_url text,
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check ((access_type = 'free' and price_paise = 0) or access_type = 'paid')
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  razorpay_order_id text unique,
  razorpay_payment_id text unique,
  amount_paise integer not null check (amount_paise > 0),
  currency text not null default 'INR',
  status text not null default 'created' check (status in ('created','paid','failed','refunded')),
  created_at timestamptz not null default now()
);

create table public.order_items (
  order_id uuid not null references public.orders(id) on delete cascade,
  resource_id uuid not null references public.resources(id),
  unit_price_paise integer not null check (unit_price_paise >= 0),
  primary key (order_id, resource_id)
);

create table public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'student' check (role in ('student','admin'))
);

alter table public.resources enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.profiles enable row level security;

-- Public catalogue may read published metadata only. Do not expose private_file_path.
create policy "Public can read published resource metadata"
  on public.resources for select using (is_published = true and access_type = 'free');

-- Students can read their own orders; creation/payment status changes happen only in trusted functions.
create policy "Users read own orders"
  on public.orders for select using (auth.uid() = user_id);
create policy "Users read own order items"
  on public.order_items for select
  using (exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));
```

**Security note:** This is a starter schema, not a complete production policy set. Add audited admin-only policies/functions for resource management and a safe public catalogue view that excludes private storage paths. Test RLS with anonymous, student and admin accounts before launch.

## 3. Storage buckets

Create two buckets:

- `free-pdfs`: public only for materials with confirmed redistribution rights.
- `premium-pdfs`: private. No public read policy. Downloads must be issued through a trusted Edge Function after checking a verified paid order.

Do not store copyrighted commercial coaching PDFs, textbooks or paid course material without explicit redistribution/commercial permission.

## 4. Razorpay flow (server-side only)

1. Browser requests an order from an authenticated Edge Function.
2. Function loads resource prices from the database (never trust prices sent by the browser) and creates a Razorpay order using the Razorpay secret stored as an Edge Function secret.
3. Browser opens Razorpay Checkout with the returned order ID and public key ID.
4. Browser submits the payment response to a verification Edge Function.
5. Function verifies the Razorpay signature using the secret, checks order ID/amount/currency, and confirms payment status with Razorpay or a verified webhook.
6. Only then does the function mark the order paid.
7. Download function checks the authenticated user owns a paid order containing the requested resource, then creates a short-lived signed URL for the private object.

Configure and verify Razorpay webhooks (including replay/idempotency handling). Never trust a success redirect or a JavaScript callback alone. Do not expose Razorpay Key Secret or Supabase service-role key.

## 5. Admin upload flow

- Admin signs in through Supabase Auth.
- A trusted Edge Function checks the admin role.
- Upload PDFs to the correct bucket, validate MIME type and file size, and store metadata.
- Paid PDFs go only to `premium-pdfs`; free PDFs go to `free-pdfs` only after rights review.
- Publish/unpublish through an admin-only server operation.

## 6. Environment values still needed

No secrets should be sent in chat or committed to the repository. Configure these in the hosting/backend dashboards:

- Supabase project URL
- Supabase anon/public key (safe for browser use with correct RLS)
- Supabase service-role key (Edge Function secret only)
- Razorpay Key ID (public checkout identifier)
- Razorpay Key Secret (Edge Function secret only)
- Razorpay webhook secret (Edge Function secret only)

## 7. Go-live checklist

- [ ] Supabase RLS tested for anonymous/student/admin users
- [ ] Admin role cannot be self-assigned
- [ ] Private bucket has no public read access
- [ ] Razorpay order amount is calculated server-side
- [ ] Signature and webhook verification tested
- [ ] Duplicate webhook events are idempotent
- [ ] Refund/revocation process defined
- [ ] Signed URLs expire quickly
- [ ] Privacy policy, terms, refund policy and contact details published
- [ ] Rights/permission evidence recorded for every PDF
