# EduStore

EduStore is a static storefront hosted on GitHub Pages. The current implementation supports a bilingual (English/Hindi) catalogue shell and reads published resource metadata from `resources.json`.

## Current status

- Static storefront: ready for GitHub Pages.
- Categories: CA Foundation, CA Intermediate, MBBS / Medical, Class 11–12 Commerce, Class 11–12 Science, UPSC / OPSC, NEET / JEE, Other Competitive Exams, Other Subjects.
- Language switch: English / Hindi (interface labels).
- Catalogue: `resources.json` (currently empty; add only real, verified PDF resources).
- Free PDF links: supported for publicly distributable PDFs.
- Paid purchases, private file delivery, admin authentication and live uploads: **not enabled**. GitHub Pages cannot run trusted server-side code.

## Publish on GitHub Pages

1. Copy the contents of this folder into the root of `Rithik114/Edustore`.
2. Commit and push to the branch/folder configured in GitHub Pages.
3. Confirm `https://edustore.in/resources.json` opens and returns `[]`.
4. Open the website and check the category filters and English/Hindi switch.

## Add a catalogue item

Edit `resources.json`. Example:

```json
[
  {
    "id": "eds-0001",
    "title": {"en": "Example free revision notes", "hi": "उदाहरण पुनरावृत्ति नोट्स"},
    "description": {"en": "A short description.", "hi": "एक संक्षिप्त विवरण।"},
    "category": "CA Foundation",
    "subject": "Accounting",
    "language": "English",
    "access": "free",
    "pricePaise": 0,
    "pages": 12,
    "fileUrl": "pdfs/free/example-notes.pdf",
    "coverEmoji": "📘"
  }
]
```

For free files, put only content that EduStore has permission to redistribute in a public `pdfs/free/` folder and set `fileUrl` to its relative URL. Do not put paid PDFs, API secrets, customer information, or payment credentials in this public repository.

## Required before paid launch

Read `SUPABASE_SETUP.md`. A secure backend is required for admin sign-in, private PDF storage, payment order creation, Razorpay signature verification, entitlement checks and short-lived download links. Never mark an order paid based only on a browser redirect or client-side JavaScript.
